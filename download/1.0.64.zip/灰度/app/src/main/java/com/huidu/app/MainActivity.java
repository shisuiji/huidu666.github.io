package com.huidu.app;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity{
	@Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		setContentView(R.layout.main);

		Button btn03 = findViewById(R.id.btn03);
        btn03.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
					Intent intent = new Intent(MainActivity.this, HuiduActivity.class);
					startActivity(intent);
				}});

	    Button btn01 = findViewById(R.id.btn01);
        btn01.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
					WebActivity.skip(MainActivity.this, "https://xiaobeiit.com/img/huidu/reward.png");
				}});
	    Button btn02 = findViewById(R.id.btn02);
        btn02.setOnClickListener(new View.OnClickListener() {
			    @Override
				public void onClick(View v){
					WebActivity.skip(MainActivity.this, "https://huidu.xiaobeiit.com/ruanjianku.html");
				}});
	    Button btn04 = findViewById(R.id.btn04);
        btn04.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.com/img/huidu/qhb.png");
				}});
	    Button btn05 = findViewById(R.id.btn05);
        btn05.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.com/huidu/lingzanba.html");
				}});
	    Button btn06 = findViewById(R.id.btn06);
        btn06.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.com/huidu/liulanba.html");
				}});
	    Button btn07 = findViewById(R.id.btn07);
        btn07.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://huidu.xiaobeiit.com/huidu/manual/index.html");
				}});
	    Button btn08 = findViewById(R.id.btn08);
        btn08.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://xiaobeiit.com/huidu/shuoshuoba.html");
				}});
	    Button btn09 = findViewById(R.id.btn09);
        btn09.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip(MainActivity.this, "https://huidu.xiaobeiit.com/shisui/index.html");
				}});
	}}

package com.huidu.app;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class HuiduActivity extends Activity{
	@Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        setContentView(R.layout.huidu);

	    Button btn11 = findViewById(R.id.btn11);
        btn11.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/huidu/nnxw.html");
				}});
	    Button btn12 = findViewById(R.id.btn12);
        btn12.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/lhb.html");
				}});
		Button btn13= findViewById(R.id.btn13);
        btn13.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
				    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/xiaofeiji.html");
				}});
	    Button btn14 = findViewById(R.id.btn14);
        btn14.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/huidu/shiguangxz/index.html");
				}});
        Button btn15= findViewById(R.id.btn15);
        btn15.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
				    String url="mqqwpa://im/chat?chat_type=wpa&uin=1653131174";
				    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); 
				}});
	    Button btn16 = findViewById(R.id.btn16);
        btn16.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/zyh.html");
				}});
	    Button btn17 = findViewById(R.id.btn17);
        btn17.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu.xyz/kaiyuan.html");
				}});
		Button btn18= findViewById(R.id.btn18);
		btn18.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p1){
					joinQQGroup("VglHAPvxiNNFWXO0MrqcTxjdKdQzl0Bb");
				}});
		Button btn19 = findViewById(R.id.btn19);
        btn19.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){
                    WebActivity.skip2(HuiduActivity.this, "https://huidu666.github.io/update.html");
				}});
	}
	public boolean joinQQGroup(String key){
		Intent intent = new Intent();
		intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
		try{
			startActivity(intent);
			return true;
		}
		catch (Exception e){
			return false;
		}
	}}

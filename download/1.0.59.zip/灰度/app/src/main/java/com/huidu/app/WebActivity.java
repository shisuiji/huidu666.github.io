package com.huidu.app;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import android.content.res.*;
import android.content.pm.*;

public class WebActivity extends Activity{
	private WebView wv;
	private FrameLayout vc;
	private String webViewUrl;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		getWindow().setFlags(
			WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
			WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        setContentView(R.layout.browser);
        wv = findViewById(R.id.webView);
        vc = findViewById(R.id.videoContainer);
		getData();
		initViews();
		loadData();
		wv.setOnTouchListener(new OnTouchListener(){
				@Override
				public boolean onTouch(View p1, MotionEvent p2){
					switch (p2.getAction()){
						case MotionEvent.ACTION_DOWN:
						case MotionEvent.ACTION_UP:
							if (!p1.hasFocus()){
								p1.requestFocus();
							}
							break;
					}
					return false;
				}
			});
		wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
		wv.setHorizontalScrollBarEnabled(false);
		wv.setVerticalScrollBarEnabled(false);
		wv.getSettings().setBuiltInZoomControls(false);
		wv.getSettings().setUseWideViewPort(true);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
		wv.getSettings().setLoadWithOverviewMode(true);	
		wv.getSettings().setSupportZoom(true);
		wv.setBackgroundColor(0);
		wv.getBackground().setAlpha(2);
		wv.setWebChromeClient(new WebChromeClient(){
				private WebChromeClient.CustomViewCallback mCallBack;
				@Override
				public boolean onJsAlert(WebView view, String url, String message, JsResult result){
					Log.i("WebActivity", "onJsAlert url=" + url + ";message=" + message);
					Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
					result.confirm();
					return true;
				}
				@Override
				public void onShowCustomView(View view, CustomViewCallback callback){
					fullScreen();
					wv.setVisibility(View.GONE);
					vc.setVisibility(View.VISIBLE);
					vc.addView(view);
					mCallBack = callback;
					super.onShowCustomView(view, callback);
				}
				@Override
				public void onHideCustomView(){
					fullScreen();
					if (mCallBack!=null){
						mCallBack.onCustomViewHidden();
					}
					wv.setVisibility(View.VISIBLE);
					vc.setVisibility(View.GONE);
					vc.removeAllViews();
					super.onHideCustomView();
				}
				private void fullScreen(){
					if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
						setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
					}
					else{
						setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					}}
			});
		wv.setWebViewClient(new WebViewClient(){
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url){
					return false;
				}
			});
		wv.setDownloadListener(new DownloadListener() {
				@Override
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength)
				{
					Intent i = new Intent(Intent.ACTION_VIEW);
					i.setData(Uri.parse(url));
					startActivity(i);
				}});
	}
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if (keyCode == KeyEvent.KEYCODE_BACK && wv.canGoBack()){
            wv.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override
    protected void onDestroy(){
        if (wv != null){
            wv.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            wv.clearHistory();
            ((ViewGroup) wv.getParent()).removeView(wv);
            wv.destroy();
            wv = null;
        }
        super.onDestroy();
    }
    private void getData(){
        webViewUrl = getIntent().getStringExtra("webview_url");
    }
    private void initViews(){
		wv.loadUrl(webViewUrl);
    }
    private void loadData(){
		wv.loadUrl(webViewUrl);
    }
    public static void skip(Activity MainActivity, String webviewUrl){
        Intent intent = new Intent(MainActivity, WebActivity.class);
        intent.putExtra("webview_url", webviewUrl);
        MainActivity.startActivity(intent);}
    public static void skip2(Activity HuiduActivity, String webviewUrl){
        Intent intent = new Intent(HuiduActivity, WebActivity.class);
        intent.putExtra("webview_url", webviewUrl);
        HuiduActivity.startActivity(intent);}
}
